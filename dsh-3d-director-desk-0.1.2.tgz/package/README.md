# dsh-3d-director-desk（DSH 工作台插件包）

把本仓库的 3D 导演台接入 DeepSeek Harness（DSH Desktop）的工作台插件包。一个包同时是：

- **npm 包**：`dsh plugin add` 可安装的 `.tgz`；
- **DSH 插件（bundle）**：`cordis.patch.yml` 把服务端入口插入 Harness 插件树；
- **Desktop 工作台**：客户端经 `desktopWorkbenches.register()` 注册「3D 导演台」面板；
- **MCP 工具来源**：patch 里的 `dsh-mcp-client` 条目把桥的 `/mcp` 门面注册为
  `mcp__director-desk__stage_* / camera_* / preview_*` 原生工具。

## 架构

```
DSH 会话（模型调用 mcp__director-desk__*）
  ▼
dsh-mcp-client（harness 进程，streamable-http → 127.0.0.1:17372/mcp）
  ▼
director-mcp 桥（由 dsh/index.js spawn 并监管；数据目录 = dshHomePath('3d-director-desk')）
  │ SSE tool_call
  ▼
executor = 工作台面板 iframe 里的导演台编辑器（用户实时看到摆场/运镜/出片）
```

- 桥进程生命周期归插件所有：插件停用/卸载/Harness 重启时随之退出；
- 数据落 `$DSH_HOME/3d-director-desk/`（`DIRECTOR_STORE_DIR`），卸载插件不删数据；
- 客户端外壳只用宿主基线 React（18.x）；React 19 + three.js 的应用跑在 iframe 里，
  桥地址经 `/api/director-desk.bridge-info` 动态发现。

## 目录

```
dsh-plugin/
├── package.json          # npm 与 dsh.bundle.patch / dsh.client 声明
├── cordis.patch.yml      # 工作台条目 + dsh-mcp-client 条目
├── dsh/index.js          # 服务端入口：拉起桥 + bridge-info API + 健康检查
├── lib/client.js         # 客户端单文件（工具栏 + iframe 外壳）
├── scripts/sync-assets.mjs  # 打包前同步 bridge/（director-mcp）与 site/（web/dist）
├── bridge/               # 生成目录（gitignore）：桥运行时
└── site/                 # 生成目录（gitignore）：web/dist 构建产物
```

## 构建与安装

```bash
# 1. 构建前端（仓库根）
cd web && npm install && npm run build

# 2. 同步资产并打包（dsh-plugin/）
cd ../dsh-plugin && npm run pack:all   # = sync + npm pack，产出 dsh-3d-director-desk-0.1.0.tgz

# 3. 安装到 DSH Desktop（按实际版本支持的方式）
dsh plugin --profile web add /绝对路径/dsh-3d-director-desk-0.1.0.tgz
# 安装后按界面提示重启 Harness
```

## 阶段状态（诚实边界）

| 能力 | 状态 |
| --- | --- |
| 包格式（第 3 节必须项） | 已实现，未在真实 Desktop 安装验证 |
| 服务端拉起桥 + bridge-info | 已实现，未验证 |
| MCP 工具注册（streamable-http） | 配置已写，未验证：dsh-mcp-client 对无状态 JSON-RPC `/mcp` 的兼容性需实测 |
| 工作台面板（iframe 外壳） | 已实现，未验证：桥尚无 `/app/` 静态站点路由（阶段二） |
| 会话归属 / conversation 节点 | 未实现（阶段二） |
| 已知限制 | mcp 条目 url 与插件 port 配置需同步手改；未做 Windows 实测 |

## 验收（待执行清单）

按工作台开发规范第 8 节：`pnpm pack` 产物内容核对（package.json、dsh/、lib/、bridge/、site/、
cordis.patch.yml）、安装重启、`dsh --profile web --dump-config` 出现两层条目、
工作台市场「已安装」出现条目、左侧切换入口、真实业务面板、原生会话中调用
`mcp__director-desk__stage_place_character` 全链路。
